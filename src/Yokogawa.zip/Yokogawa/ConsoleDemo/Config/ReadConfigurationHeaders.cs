﻿using System.IO;
using Microsoft.Extensions.Configuration;






namespace ConsoleDemo.Config
{

    public static class ReadConfigurationHeaders
    {

        public static IConfiguration Configuration;

        public static void InitConfigurationHeaders()
        {
            Configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .Build();
        }




    }
}
