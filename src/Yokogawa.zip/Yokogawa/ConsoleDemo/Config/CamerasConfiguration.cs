﻿using System;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;




namespace ConsoleDemo.Config
{
    public static class CamerasConfiguration
    {
        public static List<string> Ips;
        public static List<int> MaxNumBuffers;
        public static List<int> ExposureTimeRaws;
        public static List<int> TriggerDelayAbs;
        public static List<int> GainRaws;
        public static List<bool> CenterXs;
        public static List<bool> CenterYs;
        public static List<int> Widths;
        public static List<int> Heights;
        public static List<bool> ReverseXs;
        public static List<bool> ReverseYs;

        public static void InitCamerasConfiguration(){

            Ips = new List<string>(); ReadConfigurationHeaders.Configuration.GetSection("CameraConfiguration:Ips").Bind(Ips);
            MaxNumBuffers = new List<int>(); ReadConfigurationHeaders.Configuration.GetSection("CameraConfiguration:MaxNumBuffers").Bind(MaxNumBuffers);
            ExposureTimeRaws = new List<int>(); ReadConfigurationHeaders.Configuration.GetSection("CameraConfiguration:ExposureTimeRaws").Bind(ExposureTimeRaws);
            TriggerDelayAbs = new List<int>(); ReadConfigurationHeaders.Configuration.GetSection("CameraConfiguration:TriggerDelayAbs").Bind(TriggerDelayAbs);
            GainRaws = new List<int>(); ReadConfigurationHeaders.Configuration.GetSection("CameraConfiguration:GainRaws").Bind(GainRaws);
            CenterXs = new List<bool>(); ReadConfigurationHeaders.Configuration.GetSection("CameraConfiguration:CenterXs").Bind(CenterXs);
            CenterYs = new List<bool>(); ReadConfigurationHeaders.Configuration.GetSection("CameraConfiguration:CenterYs").Bind(CenterYs);
            Widths = new List<int>(); ReadConfigurationHeaders.Configuration.GetSection("CameraConfiguration:Widths").Bind(Widths);
            Heights = new List<int>(); ReadConfigurationHeaders.Configuration.GetSection("CameraConfiguration:Heights").Bind(Heights);
            ReverseXs = new List<bool>(); ReadConfigurationHeaders.Configuration.GetSection("CameraConfiguration:ReverseXs").Bind(ReverseXs);
            ReverseYs = new List<bool>(); ReadConfigurationHeaders.Configuration.GetSection("CameraConfiguration:ReverseYs").Bind(ReverseYs);
        }


    }
}
