﻿using System;
using SkiaSharp;
using Basler.Pylon;
using ConsoleDemo.Services;
using System.Collections.Generic;
using System.IO;
using OpenCvSharp;
using OpenCvSharp.Aruco;
using ConsoleDemo.Config;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;



// Console.CursorVisible = false;
// https://github.com/shimat/opencvsharp





namespace Grab
{
    class Grab
    {
        internal static void Main()
        {

            // Configuration
            ReadConfigurationHeaders.InitConfigurationHeaders();
            CamerasConfiguration.InitCamerasConfiguration();

            // BaslerCameraGigE Services
            BaslerCameraGigE.InitBaslerCameraGigE(cameras: out List<Basler.Pylon.Camera> cameras);


            while (true)
            {
                // Detection
                SystemDiagnostics.StopwatchProcess(stopwatch: new Stopwatch(), stopwatchOutput: out Stopwatch stopwatchOutput);

                BaslerCameraGigE.AcquireSingleFrameBaslerCameraGigE(cameras: cameras, grabResults: out List<IGrabResult> grabResults);            
                ImageProcessing.ConvertGrabResultListToSKImage(grabResults: grabResults, images: out List<SKImage> images);
                ImageProcessing.ConvertSKImageToMat(skImage: images.FirstOrDefault(), out Mat imageMat);

                // Read image from path
                // using var image = SKImage.FromEncodedData(@"C:\Users\tiger\Downloads\Trianing\Yokogawa\ConsoleDemo\Images\s.png");
                // ImageProcessing.ConvertSKImageToMat(skImage: image, out Mat imageMat);


                BaslerCameraGigE.ClearSingleFrameBuffersBaslerCameraGigE(grabResults: grabResults, grabResultsOutput: out grabResults);
                foreach (SKImage img in images) { img.Dispose(); } images.Clear();
                foreach (IGrabResult grabResult in grabResults) { grabResult.Dispose(); } grabResults.Clear();


                Cv2.NamedWindow($"Image Output", WindowFlags.Normal);
                Cv2.ImShow($"Image Output", imageMat);

                int key = Cv2.WaitKey(1);
                if (key == 27)
                {
                    Cv2.DestroyAllWindows();
                    break;
                }


            }
            
            BaslerCameraGigE.CloseInitBaslerCameraGigE(cameras: cameras, camerasOutput: out cameras);
            foreach (Basler.Pylon.Camera camera in cameras) { camera.Dispose(); } cameras.Clear();
            
            


            
        }

    }
}










