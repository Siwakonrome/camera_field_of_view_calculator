﻿using System;
using System.Diagnostics;




namespace ConsoleDemo.Services
{
    public static class SystemDiagnostics
    {



        public static void StopwatchProcess(Stopwatch stopwatch, out Stopwatch stopwatchOutput, bool isStart = true, string processName = null){
            if (isStart){
                stopwatch.Start();
            }
            else{
                stopwatch.Stop();
                Console.WriteLine($"{processName} Process time: {stopwatch.ElapsedMilliseconds} ms");
                Console.WriteLine("---------------------------------------------------------------");
                stopwatch.Reset();
                stopwatch = null;
            }
            stopwatchOutput = stopwatch;
        }

        


    }
}