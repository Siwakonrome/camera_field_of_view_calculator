﻿using System;
using SkiaSharp;
using Basler.Pylon;
using System.Runtime.InteropServices;
using System.Drawing; // For Bitmap
using System.Drawing.Imaging; // For BitmapData
using OpenCvSharp;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Collections.Concurrent;



namespace ConsoleDemo.Services
{

    

    public static class ImageProcessing
    {

        private static SKImage ConvertGrabResultToSKImage(IGrabResult grabResult)
        {
            ConvertGrabResultToMat(grabResult: grabResult, bgrImage: out Mat bgrImage);
            ConvertMatToSKImage(mat: bgrImage, matOutput: out bgrImage, sKImage: out SKImage sKImage); bgrImage.Dispose();
            return sKImage;
        }


        public static void ConvertGrabResultListToSKImage(List<IGrabResult> grabResults, out List<SKImage> images)
        {
            images = new List<SKImage>();
            foreach(IGrabResult grabResult in grabResults){ images.Add(ConvertGrabResultToSKImage(grabResult: grabResult)); }
        }
       

        public static void ConvertSKImageToMat(SKImage skImage, out Mat mat)
        {
            byte[] imageData = null; imageData = skImage.Encode().ToArray();
            mat = Cv2.ImDecode(buf: imageData, flags: ImreadModes.Color);
            imageData = null;
            return;
        }


        private static void ConvertMatToSKImage(Mat mat, out Mat matOutput, out SKImage sKImage)
        {
            sKImage = SKImage.FromEncodedData(new SKMemoryStream(mat.Clone().ToBytes(".png")));
            mat.Dispose(); matOutput = mat;
        }

        private static void ConvertGrabResultToMat(IGrabResult grabResult, out Mat bgrImage)
        {
            bgrImage = new Mat();
            byte[] buffer = grabResult.PixelData as byte[];
            if (buffer == null){ return; }
            Mat bayerImage = new Mat(grabResult.Height, grabResult.Width, MatType.CV_8UC1);
            Marshal.Copy(buffer, 0, bayerImage.Data, buffer.Length);
            Cv2.CvtColor(bayerImage.Clone(), bgrImage, ColorConversionCodes.BayerBG2BGR);
            bayerImage.Dispose(); buffer = null;
            return;
        }



    }
}



