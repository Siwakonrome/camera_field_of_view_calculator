﻿using Basler.Pylon;
using ConsoleDemo.Config;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections.Concurrent;


namespace ConsoleDemo.Services
{
    public static class BaslerCameraGigE
    {

        public static void InitBaslerCameraGigE(out List<Basler.Pylon.Camera> cameras)
        {
            cameras = new List<Camera>();
            for (int i = 0; i < CamerasConfiguration.Ips.Count; i++){
                Camera camera = new Camera(CamerasConfiguration.Ips[i]);
                camera.CameraOpened += Configuration.AcquireSingleFrame;
                camera.Open();
                camera.Parameters[PLCamera.PixelFormat].SetValue("BayerRG8");
                camera.Parameters[PLCamera.AcquisitionMode].SetValue("SingleFrame");
                camera.Parameters[PLCameraInstance.MaxNumBuffer].SetValue(CamerasConfiguration.MaxNumBuffers[i]);
                camera.Parameters[PLCamera.ExposureTimeRaw].SetValue(CamerasConfiguration.ExposureTimeRaws[i]);
                camera.Parameters[PLCamera.TriggerDelayAbs].SetValue(CamerasConfiguration.TriggerDelayAbs[i]);
                camera.Parameters[PLCamera.GainRaw].SetValue(CamerasConfiguration.GainRaws[i]);
                camera.Parameters[PLCamera.CenterX].SetValue(CamerasConfiguration.CenterXs[i]);
                camera.Parameters[PLCamera.CenterY].SetValue(CamerasConfiguration.CenterYs[i]);
                camera.Parameters[PLCamera.Width].SetValue(CamerasConfiguration.Widths[i]);
                camera.Parameters[PLCamera.Height].SetValue(CamerasConfiguration.Heights[i]);
                camera.Parameters[PLCamera.ReverseX].SetValue(CamerasConfiguration.ReverseXs[i]);
                camera.Parameters[PLCamera.ReverseY].SetValue(CamerasConfiguration.ReverseYs[i]);
                camera.StreamGrabber.Start();
                cameras.Add(camera);
                camera = null;
                // clear camera.
            }
        }

        public static void AcquireSingleFrameBaslerCameraGigE(List<Basler.Pylon.Camera> cameras, out List<IGrabResult> grabResults)
        {
            SystemDiagnostics.StopwatchProcess(stopwatch: new Stopwatch(),
                                               stopwatchOutput: out Stopwatch stopwatchOutput);
            grabResults = new List<IGrabResult>();
            List<IGrabResult> grabResultsQueue = new List<IGrabResult>();
            foreach (Basler.Pylon.Camera camera in cameras){

                camera.Parameters[PLCamera.AcquisitionStart].Execute();
                IGrabResult grabResult = camera.StreamGrabber.RetrieveResult(5000, TimeoutHandling.ThrowException);
                if (grabResult.GrabSucceeded)
                {
                    byte[] buffer = grabResult.PixelData as byte[];
                    grabResultsQueue.Add(grabResult.Clone());
                }
                grabResult.Dispose();
            }
            foreach (IGrabResult img in grabResultsQueue){ grabResults.Add(img.Clone()); img.Dispose(); }
            foreach (IGrabResult img in grabResultsQueue) { img.Dispose(); } grabResultsQueue.Clear();
            SystemDiagnostics.StopwatchProcess(stopwatch: stopwatchOutput,
                                               stopwatchOutput: out stopwatchOutput,
                                               isStart: false,
                                               processName: $"Acquired Images");
        }


        public static void ClearSingleFrameBuffersBaslerCameraGigE(List<IGrabResult> grabResults, out List<IGrabResult> grabResultsOutput)
        {
            grabResultsOutput = new List<IGrabResult>();
            for (int i = 0; i < grabResults.Count; i++){
                grabResults[i].Dispose();
                grabResultsOutput.Add(grabResults[i]);
            }
        }


        public static void CloseInitBaslerCameraGigE(List<Basler.Pylon.Camera> cameras, out List<Basler.Pylon.Camera> camerasOutput)
        {
            camerasOutput = new List<Camera>();
            for (int i = 0; i < cameras.Count; i++)
            {
                cameras[i].StreamGrabber.Stop();
                cameras[i].Close();
                cameras[i].Dispose();
                camerasOutput.Add(cameras[i]);
            }
        }

        


    }
}





